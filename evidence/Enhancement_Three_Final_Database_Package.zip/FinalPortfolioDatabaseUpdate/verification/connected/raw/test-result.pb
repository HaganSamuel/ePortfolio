
�
�
DatabaseHistoryTestcom.example.inventoryappproject2deleteRetainsSnapshotAndNullsDeletedItemForeignKey2��������:��������B
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.DatabaseHistoryTest-deleteRetainsSnapshotAndNullsDeletedItemForeignKey.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo�
�
DatabaseHistoryTestcom.example.inventoryappproject%deleteRollsBackWhenHistoryInsertFails2������ֵ:��������B
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.DatabaseHistoryTest-deleteRollsBackWhenHistoryInsertFails.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo�
�
DatabaseHistoryTestcom.example.inventoryappproject%updateRollsBackWhenHistoryInsertFails2��������:�������B
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.DatabaseHistoryTest-updateRollsBackWhenHistoryInsertFails.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo�
�
DatabaseHistoryTestcom.example.inventoryappproject-addWritesTimestampsAndAccurateHistorySnapshot2������ݥ:������ؠB
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.DatabaseHistoryTest-addWritesTimestampsAndAccurateHistorySnapshot.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo�
�
DatabaseHistoryTestcom.example.inventoryappproject/historyIsNewestFirstWithDeterministicIdTieBreak2������:������4B
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.DatabaseHistoryTest-historyIsNewestFirstWithDeterministicIdTieBreak.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo�
�
DatabaseHistoryTestcom.example.inventoryappproject7wrongOwnerUpdateAndDeleteChangeNothingAndWriteNoHistory2�������5:������ٰB
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.DatabaseHistoryTest-wrongOwnerUpdateAndDeleteChangeNothingAndWriteNoHistory.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo�
�
DatabaseHistoryTestcom.example.inventoryappproject5updatePreservesCreatedTimeAndRecordsBeforeAfterValues2������ӱ:�����ߡ�B
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.DatabaseHistoryTest-updatePreservesCreatedTimeAndRecordsBeforeAfterValues.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo�
�
DatabaseHistoryTestcom.example.inventoryappproject$historyQueriesAreStrictlyOwnerScoped2�����蛠:��������B
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.DatabaseHistoryTest-historyQueriesAreStrictlyOwnerScoped.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo�
�
DatabaseHistoryTestcom.example.inventoryappproject)foreignKeysAndCheckConstraintsAreEnforced2��������:��������B
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.DatabaseHistoryTest-foreignKeysAndCheckConstraintsAreEnforced.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo�
�
DatabaseHistoryTestcom.example.inventoryappproject"addRollsBackWhenHistoryInsertFails2������:�������5B
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.DatabaseHistoryTest-addRollsBackWhenHistoryInsertFails.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo�
�
DatabaseMigrationTestcom.example.inventoryappproject8versionThreeHistorySurvivesIndexOnlyVersionFourMigration2�������6:��������B
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.DatabaseMigrationTest-versionThreeHistorySurvivesIndexOnlyVersionFourMigration.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo�
�
DatabaseMigrationTestcom.example.inventoryappprojectBversionTwoInventorySurvivesCurrentUpgradeWithOneMigrationTimestamp2��������:������ǚB
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.DatabaseMigrationTest-versionTwoInventorySurvivesCurrentUpgradeWithOneMigrationTimestamp.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo�
�
DatabaseMigrationTestcom.example.inventoryappproject8versionOneUsersAndInventorySurviveDirectCurrentMigration2��������:������҈B
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.DatabaseMigrationTest-versionOneUsersAndInventorySurviveDirectCurrentMigration.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo�

ExampleInstrumentedTestcom.example.inventoryappprojectuseAppContext2������̉:������ƊB
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.ExampleInstrumentedTest-useAppContext.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo�
�
InventoryHistoryPaginationTestcom.example.inventoryappproject-secondPageReturnsNextRecordsWithoutDuplicates2�����؃�:�������kB
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.InventoryHistoryPaginationTest-secondPageReturnsNextRecordsWithoutDuplicates.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo�
�
InventoryHistoryPaginationTestcom.example.inventoryappproject+invalidSizesAndIncompleteCursorsAreRejected2�������k:��������B
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.InventoryHistoryPaginationTest-invalidSizesAndIncompleteCursorsAreRejected.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo�
�
InventoryHistoryPaginationTestcom.example.inventoryappproject)finalPartialPageContainsOnlyRemainingRows2�������:��������B
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.InventoryHistoryPaginationTest-finalPartialPageContainsOnlyRemainingRows.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo�
�
InventoryHistoryPaginationTestcom.example.inventoryappproject8combiningThreePagesReproducesExpectedNewestFirstSequence2��������:�������RB
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.InventoryHistoryPaginationTest-combiningThreePagesReproducesExpectedNewestFirstSequence.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo�
�
InventoryHistoryPaginationTestcom.example.inventoryappproject0loadMoreUiAppendsAndRotationDoesNotDuplicateRows2�������S:Ï������B
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.InventoryHistoryPaginationTest-loadMoreUiAppendsAndRotationDoesNotDuplicateRows.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo�
�
InventoryHistoryPaginationTestcom.example.inventoryappproject"ownerIsolationHoldsAcrossEveryPage2Ï������:ŏ����ؿB
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.InventoryHistoryPaginationTest-ownerIsolationHoldsAcrossEveryPage.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo�
�
InventoryHistoryPaginationTestcom.example.inventoryappproject1equalActionTimesUseHistoryIdCursorWithoutSkipping2ŏ������:Ə�����B
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.InventoryHistoryPaginationTest-equalActionTimesUseHistoryIdCursorWithoutSkipping.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo�
�
InventoryHistoryPaginationTestcom.example.inventoryappproject'firstPageReturnsNoMoreThanFixedPageSize2Ə���Շ	:Ə�����B
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.InventoryHistoryPaginationTest-firstPageReturnsNoMoreThanFixedPageSize.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo�
�
InventoryHistoryPaginationTestcom.example.inventoryappproject!emptyHistoryReturnsEmptyFirstPage2Ə�����:Ǐ������B
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.InventoryHistoryPaginationTest-emptyHistoryReturnsEmptyFirstPage.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\testlog\test-results.log 2
text/plain