package com.example.inventoryappproject;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

@RunWith(AndroidJUnit4.class)
public class DatabaseMigrationTest {
    private Context context;
    private DatabaseHelper migrated;

    @Before
    public void setUp() {
        context = InstrumentationRegistry.getInstrumentation().getTargetContext();
        context.deleteDatabase(DatabaseHelper.DATABASE_NAME);
    }

    @After
    public void tearDown() {
        if (migrated != null) migrated.close();
        context.deleteDatabase(DatabaseHelper.DATABASE_NAME);
    }

    @Test
    public void versionTwoInventorySurvivesVersionThreeWithOneMigrationTimestamp() {
        createVersionTwoDatabase();

        migrated = new DatabaseHelper(context);
        SQLiteDatabase database = migrated.getWritableDatabase();
        List<InventoryItem> items = migrated.getItems(7);

        assertEquals(3, database.getVersion());
        assertEquals(2, items.size());
        assertEquals("Paper", items.get(0).getItemName());
        assertEquals(3, items.get(0).getQuantity());
        assertEquals("Pens", items.get(1).getItemName());
        assertTrue(items.get(0).getCreatedAt() > 0);
        assertEquals(items.get(0).getCreatedAt(), items.get(0).getUpdatedAt());
        assertEquals(items.get(0).getCreatedAt(), items.get(1).getCreatedAt());
        assertEquals(items.get(1).getCreatedAt(), items.get(1).getUpdatedAt());
        assertTrue(tableExists(database, "inventory_history"));
        assertTrue(indexExists(database, "idx_history_owner_time"));
        assertTrue(indexExists(database, "idx_history_item_time"));
        assertTrue(migrated.getHistoryForOwner(7).isEmpty());
    }

    @Test
    public void versionOneUsersAndInventorySurviveDirectVersionThreeMigration() {
        SQLiteDatabase v1 = context.openOrCreateDatabase(
                DatabaseHelper.DATABASE_NAME, Context.MODE_PRIVATE, null);
        v1.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "username TEXT UNIQUE NOT NULL, password TEXT NOT NULL)");
        v1.execSQL("CREATE TABLE inventory (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "item_name TEXT NOT NULL, quantity INTEGER NOT NULL, "
                + "threshold_value INTEGER NOT NULL)");
        v1.execSQL("INSERT INTO users(id,username,password) VALUES(7,'sam','secret')");
        v1.execSQL("INSERT INTO inventory(id,item_name,quantity,threshold_value) "
                + "VALUES(11,'Paper',3,5)");
        v1.setVersion(1);
        v1.close();

        migrated = new DatabaseHelper(context);
        SQLiteDatabase database = migrated.getWritableDatabase();
        assertEquals(7, migrated.validateUser("sam", "secret"));
        assertEquals(1, migrated.getItems(7).size());
        InventoryItem item = migrated.getItems(7).get(0);
        assertEquals(11, item.getId());
        assertEquals("Paper", item.getItemName());
        assertEquals(7, item.getOwnerUserId());
        assertTrue(item.getCreatedAt() > 0);
        assertEquals(item.getCreatedAt(), item.getUpdatedAt());

        Cursor columns = database.rawQuery("PRAGMA table_info(users)", null);
        boolean hasHash = false;
        boolean hasPlaintext = false;
        while (columns.moveToNext()) {
            String column = columns.getString(1);
            hasHash |= "password_hash".equals(column);
            hasPlaintext |= "password".equals(column);
        }
        columns.close();
        assertTrue(hasHash);
        assertFalse(hasPlaintext);
        assertTrue(tableExists(database, "inventory_history"));
    }

    private void createVersionTwoDatabase() {
        SQLiteDatabase v2 = context.openOrCreateDatabase(
                DatabaseHelper.DATABASE_NAME, Context.MODE_PRIVATE, null);
        v2.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, "
                + "password_salt TEXT NOT NULL)");
        v2.execSQL("CREATE TABLE inventory (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "item_name TEXT NOT NULL, quantity INTEGER NOT NULL CHECK(quantity >= 0), "
                + "threshold_value INTEGER NOT NULL CHECK(threshold_value >= 0), "
                + "owner_user_id INTEGER NOT NULL, FOREIGN KEY(owner_user_id) "
                + "REFERENCES users(id) ON DELETE CASCADE)");
        String salt = PasswordHasher.newSalt();
        v2.execSQL("INSERT INTO users(id,username,password_hash,password_salt) VALUES(?,?,?,?)",
                new Object[]{7, "sam", PasswordHasher.hash("secret", salt), salt});
        v2.execSQL("INSERT INTO inventory(id,item_name,quantity,threshold_value,owner_user_id) "
                        + "VALUES(11,'Paper',3,5,7),(12,'Pens',9,2,7)");
        v2.setVersion(2);
        v2.close();
    }

    private boolean tableExists(SQLiteDatabase database, String tableName) {
        return schemaObjectExists(database, "table", tableName);
    }

    private boolean indexExists(SQLiteDatabase database, String indexName) {
        return schemaObjectExists(database, "index", indexName);
    }

    private boolean schemaObjectExists(SQLiteDatabase database, String type, String name) {
        Cursor cursor = database.query("sqlite_master", new String[]{"name"},
                "type=? AND name=?", new String[]{type, name}, null, null, null);
        try {
            return cursor.moveToFirst();
        } finally {
            cursor.close();
        }
    }
}
