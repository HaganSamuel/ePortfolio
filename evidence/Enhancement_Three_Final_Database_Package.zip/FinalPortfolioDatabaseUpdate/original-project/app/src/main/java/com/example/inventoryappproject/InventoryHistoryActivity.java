package com.example.inventoryappproject;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/** Read-only, owner-scoped audit trail for inventory changes. */
public final class InventoryHistoryActivity extends AppCompatActivity {
    private InventoryRepository repository;
    private InventoryHistoryAdapter adapter;
    private TextView emptyView;
    private int userId = -1;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_inventory_history);

        userId = getIntent().getIntExtra("user_id", -1);
        if (userId < 0) {
            finish();
            return;
        }

        String username = getIntent().getStringExtra("username");
        if (username == null || username.trim().isEmpty()) {
            username = getString(R.string.inventory_history);
        } else {
            username = getString(R.string.history_for_user, username);
        }
        ((TextView) findViewById(R.id.textHistoryTitle)).setText(username);

        repository = new SQLiteInventoryRepository(new DatabaseHelper(this));
        adapter = new InventoryHistoryAdapter();
        emptyView = findViewById(R.id.textHistoryEmpty);
        RecyclerView recycler = findViewById(R.id.recyclerHistory);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        recycler.setAdapter(adapter);
        findViewById(R.id.buttonHistoryBack).setOnClickListener(view -> finish());
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (repository == null) return;
        List<InventoryHistoryEntry> history = repository.findHistoryForOwner(userId);
        adapter.submitList(history);
        emptyView.setVisibility(history.isEmpty() ? TextView.VISIBLE : TextView.GONE);
    }
}
