package com.example.inventoryappproject;

import java.util.List;

public final class SQLiteInventoryRepository implements InventoryRepository {
    private final DatabaseHelper database;
    public SQLiteInventoryRepository(DatabaseHelper database) { this.database = database; }
    @Override public long save(InventoryItem item) { return database.saveItem(item); }
    @Override public int delete(int itemId, int ownerId) { return database.deleteItem(itemId, ownerId); }
    @Override public List<InventoryItem> findForOwner(int ownerId) { return database.getItems(ownerId); }
    @Override public List<InventoryHistoryEntry> findHistoryForOwner(int ownerId) {
        return database.getHistoryForOwner(ownerId);
    }
}
