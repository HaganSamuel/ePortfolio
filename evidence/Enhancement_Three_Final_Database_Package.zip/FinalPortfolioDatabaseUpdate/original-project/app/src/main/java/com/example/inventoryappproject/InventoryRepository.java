package com.example.inventoryappproject;

import java.util.List;

public interface InventoryRepository {
    long save(InventoryItem item);
    int delete(int itemId, int ownerId);
    List<InventoryItem> findForOwner(int ownerId);
    List<InventoryHistoryEntry> findHistoryForOwner(int ownerId);
}
