package com.example.inventoryappproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/** SQLite persistence gateway with versioned, non-destructive migrations. */
public class DatabaseHelper extends SQLiteOpenHelper {
    static final String DATABASE_NAME = "mobile2app.db";
    static final int DATABASE_VERSION = 3;

    private static final String TABLE_USERS = "users";
    private static final String TABLE_INVENTORY = "inventory";
    private static final String TABLE_HISTORY = "inventory_history";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        createUsersTable(db);
        createVersionThreeInventoryTable(db);
        createInventoryIndex(db);
        createHistorySchema(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        int currentVersion = oldVersion;
        if (currentVersion < 2) {
            migrateVersionOneToTwo(db);
            currentVersion = 2;
        }
        if (currentVersion < 3) {
            migrateVersionTwoToThree(db);
        }
    }

    private void createUsersTable(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, "
                + "password_salt TEXT NOT NULL)");
    }

    private void createVersionTwoInventoryTable(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE inventory (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "item_name TEXT NOT NULL, quantity INTEGER NOT NULL CHECK(quantity >= 0), "
                + "threshold_value INTEGER NOT NULL CHECK(threshold_value >= 0), "
                + "owner_user_id INTEGER NOT NULL, FOREIGN KEY(owner_user_id) "
                + "REFERENCES users(id) ON DELETE CASCADE)");
    }

    private void createVersionThreeInventoryTable(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE inventory (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "item_name TEXT NOT NULL, quantity INTEGER NOT NULL CHECK(quantity >= 0), "
                + "threshold_value INTEGER NOT NULL CHECK(threshold_value >= 0), "
                + "owner_user_id INTEGER NOT NULL, created_at INTEGER NOT NULL, "
                + "updated_at INTEGER NOT NULL, FOREIGN KEY(owner_user_id) "
                + "REFERENCES users(id) ON DELETE CASCADE)");
    }

    private void createInventoryIndex(SQLiteDatabase db) {
        db.execSQL("CREATE INDEX idx_inventory_owner_name "
                + "ON inventory(owner_user_id, item_name)");
    }

    private void createHistorySchema(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE inventory_history ("
                + "history_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "inventory_item_id INTEGER, owner_user_id INTEGER NOT NULL, "
                + "item_name_snapshot TEXT NOT NULL, action_type TEXT NOT NULL "
                + "CHECK(action_type IN ('ADD','UPDATE','DELETE')), "
                + "quantity_before INTEGER, quantity_after INTEGER, "
                + "threshold_before INTEGER, threshold_after INTEGER, "
                + "action_time INTEGER NOT NULL, "
                + "FOREIGN KEY(inventory_item_id) REFERENCES inventory(id) ON DELETE SET NULL, "
                + "FOREIGN KEY(owner_user_id) REFERENCES users(id) ON DELETE CASCADE)");
        db.execSQL("CREATE INDEX idx_history_owner_time "
                + "ON inventory_history(owner_user_id, action_time DESC)");
        db.execSQL("CREATE INDEX idx_history_item_time "
                + "ON inventory_history(inventory_item_id, action_time DESC)");
    }

    private void migrateVersionOneToTwo(SQLiteDatabase db) {
        db.beginTransaction();
        try {
            db.execSQL("ALTER TABLE users RENAME TO users_v1");
            db.execSQL("ALTER TABLE inventory RENAME TO inventory_v1");
            createUsersTable(db);
            createVersionTwoInventoryTable(db);
            createInventoryIndex(db);

            int firstUserId = migrateVersionOneUsers(db);
            if (firstUserId == -1) {
                firstUserId = createLegacyInventoryOwner(db);
            }

            db.execSQL("INSERT INTO inventory(id,item_name,quantity,threshold_value,owner_user_id) "
                            + "SELECT id,item_name,quantity,threshold_value,? FROM inventory_v1",
                    new Object[]{firstUserId});
            db.execSQL("DROP TABLE inventory_v1");
            db.execSQL("DROP TABLE users_v1");
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    private int migrateVersionOneUsers(SQLiteDatabase db) {
        Cursor users = db.query("users_v1", new String[]{"id", "username", "password"},
                null, null, null, null, "id ASC");
        int firstUserId = -1;
        try {
            while (users.moveToNext()) {
                int id = users.getInt(0);
                if (firstUserId == -1) {
                    firstUserId = id;
                }
                String salt = PasswordHasher.newSalt();
                ContentValues values = new ContentValues();
                values.put("id", id);
                values.put("username", users.getString(1));
                values.put("password_salt", salt);
                values.put("password_hash", PasswordHasher.hash(users.getString(2), salt));
                db.insertOrThrow(TABLE_USERS, null, values);
            }
        } finally {
            users.close();
        }
        return firstUserId;
    }

    private int createLegacyInventoryOwner(SQLiteDatabase db) {
        String salt = PasswordHasher.newSalt();
        ContentValues legacyUser = new ContentValues();
        legacyUser.put("username", "legacy_inventory_owner");
        legacyUser.put("password_salt", salt);
        legacyUser.put("password_hash", PasswordHasher.hash(PasswordHasher.newSalt(), salt));
        return (int) db.insertOrThrow(TABLE_USERS, null, legacyUser);
    }

    private void migrateVersionTwoToThree(SQLiteDatabase db) {
        db.beginTransaction();
        try {
            long migrationTime = System.currentTimeMillis();
            db.execSQL("ALTER TABLE inventory ADD COLUMN created_at INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE inventory ADD COLUMN updated_at INTEGER NOT NULL DEFAULT 0");
            ContentValues timestamps = new ContentValues();
            timestamps.put("created_at", migrationTime);
            timestamps.put("updated_at", migrationTime);
            db.update(TABLE_INVENTORY, timestamps, null, null);
            createHistorySchema(db);
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    public boolean createUser(String username, String password) {
        String salt = PasswordHasher.newSalt();
        ContentValues values = new ContentValues();
        values.put("username", username.trim());
        values.put("password_salt", salt);
        values.put("password_hash", PasswordHasher.hash(password, salt));
        return getWritableDatabase().insert(TABLE_USERS, null, values) != -1;
    }

    public int validateUser(String username, String password) {
        Cursor cursor = getReadableDatabase().query(TABLE_USERS,
                new String[]{"id", "password_hash", "password_salt"}, "username=?",
                new String[]{username.trim()}, null, null, null);
        int userId = -1;
        try {
            if (cursor.moveToFirst()
                    && PasswordHasher.matches(password, cursor.getString(2), cursor.getString(1))) {
                userId = cursor.getInt(0);
            }
        } finally {
            cursor.close();
        }
        return userId;
    }

    public long saveItem(InventoryItem item) {
        return item.getId() < 0 ? addItem(item) : updateItem(item);
    }

    private long addItem(InventoryItem item) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            long actionTime = System.currentTimeMillis();
            ContentValues values = itemValues(item);
            values.put("owner_user_id", item.getOwnerUserId());
            values.put("created_at", actionTime);
            values.put("updated_at", actionTime);
            long itemId = db.insertOrThrow(TABLE_INVENTORY, null, values);
            insertHistory(db, itemId, item.getOwnerUserId(), item.getItemName(),
                    InventoryHistoryEntry.ActionType.ADD, null, item.getQuantity(),
                    null, item.getThreshold(), actionTime);
            db.setTransactionSuccessful();
            return itemId;
        } finally {
            db.endTransaction();
        }
    }

    private long updateItem(InventoryItem item) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            InventoryItem existing = findOwnedItem(db, item.getId(), item.getOwnerUserId());
            if (existing == null) {
                return -1;
            }

            long actionTime = nextTimestamp(existing.getUpdatedAt());
            ContentValues values = itemValues(item);
            values.put("updated_at", actionTime);
            int updated = db.update(TABLE_INVENTORY, values,
                    "id=? AND owner_user_id=?",
                    new String[]{String.valueOf(item.getId()),
                            String.valueOf(item.getOwnerUserId())});
            if (updated != 1) {
                throw new IllegalStateException("Owner-scoped inventory update failed");
            }

            insertHistory(db, item.getId(), item.getOwnerUserId(), item.getItemName(),
                    InventoryHistoryEntry.ActionType.UPDATE,
                    existing.getQuantity(), item.getQuantity(),
                    existing.getThreshold(), item.getThreshold(), actionTime);
            db.setTransactionSuccessful();
            return item.getId();
        } finally {
            db.endTransaction();
        }
    }

    public int deleteItem(int id, int ownerId) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            InventoryItem existing = findOwnedItem(db, id, ownerId);
            if (existing == null) {
                return 0;
            }

            long actionTime = nextTimestamp(existing.getUpdatedAt());
            insertHistory(db, id, ownerId, existing.getItemName(),
                    InventoryHistoryEntry.ActionType.DELETE,
                    existing.getQuantity(), null,
                    existing.getThreshold(), null, actionTime);
            int deleted = db.delete(TABLE_INVENTORY, "id=? AND owner_user_id=?",
                    new String[]{String.valueOf(id), String.valueOf(ownerId)});
            if (deleted != 1) {
                throw new IllegalStateException("Owner-scoped inventory delete failed");
            }
            db.setTransactionSuccessful();
            return deleted;
        } finally {
            db.endTransaction();
        }
    }

    private long nextTimestamp(long previousTimestamp) {
        return Math.max(System.currentTimeMillis(), previousTimestamp + 1);
    }

    private ContentValues itemValues(InventoryItem item) {
        ContentValues values = new ContentValues();
        values.put("item_name", item.getItemName());
        values.put("quantity", item.getQuantity());
        values.put("threshold_value", item.getThreshold());
        return values;
    }

    private InventoryItem findOwnedItem(SQLiteDatabase db, int id, int ownerId) {
        Cursor cursor = db.query(TABLE_INVENTORY, null,
                "id=? AND owner_user_id=?",
                new String[]{String.valueOf(id), String.valueOf(ownerId)},
                null, null, null);
        try {
            return cursor.moveToFirst() ? readItem(cursor) : null;
        } finally {
            cursor.close();
        }
    }

    private void insertHistory(
            SQLiteDatabase db,
            long inventoryItemId,
            int ownerId,
            String itemName,
            InventoryHistoryEntry.ActionType actionType,
            Integer quantityBefore,
            Integer quantityAfter,
            Integer thresholdBefore,
            Integer thresholdAfter,
            long actionTime) {
        ContentValues values = new ContentValues();
        values.put("inventory_item_id", inventoryItemId);
        values.put("owner_user_id", ownerId);
        values.put("item_name_snapshot", itemName);
        values.put("action_type", actionType.name());
        putNullableInteger(values, "quantity_before", quantityBefore);
        putNullableInteger(values, "quantity_after", quantityAfter);
        putNullableInteger(values, "threshold_before", thresholdBefore);
        putNullableInteger(values, "threshold_after", thresholdAfter);
        values.put("action_time", actionTime);
        db.insertOrThrow(TABLE_HISTORY, null, values);
    }

    private void putNullableInteger(ContentValues values, String key, Integer value) {
        if (value == null) {
            values.putNull(key);
        } else {
            values.put(key, value);
        }
    }

    public List<InventoryItem> getItems(int ownerId) {
        List<InventoryItem> items = new ArrayList<>();
        Cursor cursor = getReadableDatabase().query(TABLE_INVENTORY, null,
                "owner_user_id=?", new String[]{String.valueOf(ownerId)},
                null, null, "item_name COLLATE NOCASE ASC, id ASC");
        try {
            while (cursor.moveToNext()) {
                items.add(readItem(cursor));
            }
        } finally {
            cursor.close();
        }
        return items;
    }

    private InventoryItem readItem(Cursor cursor) {
        return new InventoryItem(
                cursor.getInt(cursor.getColumnIndexOrThrow("id")),
                cursor.getString(cursor.getColumnIndexOrThrow("item_name")),
                cursor.getInt(cursor.getColumnIndexOrThrow("quantity")),
                cursor.getInt(cursor.getColumnIndexOrThrow("threshold_value")),
                cursor.getInt(cursor.getColumnIndexOrThrow("owner_user_id")),
                cursor.getLong(cursor.getColumnIndexOrThrow("created_at")),
                cursor.getLong(cursor.getColumnIndexOrThrow("updated_at")));
    }

    public List<InventoryHistoryEntry> getHistoryForOwner(int ownerId) {
        List<InventoryHistoryEntry> history = new ArrayList<>();
        Cursor cursor = getReadableDatabase().query(TABLE_HISTORY, null,
                "owner_user_id=?", new String[]{String.valueOf(ownerId)},
                null, null, "action_time DESC, history_id DESC");
        try {
            while (cursor.moveToNext()) {
                history.add(readHistoryEntry(cursor));
            }
        } finally {
            cursor.close();
        }
        return history;
    }

    private InventoryHistoryEntry readHistoryEntry(Cursor cursor) {
        int itemIdColumn = cursor.getColumnIndexOrThrow("inventory_item_id");
        return new InventoryHistoryEntry(
                cursor.getLong(cursor.getColumnIndexOrThrow("history_id")),
                cursor.isNull(itemIdColumn) ? null : cursor.getInt(itemIdColumn),
                cursor.getInt(cursor.getColumnIndexOrThrow("owner_user_id")),
                cursor.getString(cursor.getColumnIndexOrThrow("item_name_snapshot")),
                InventoryHistoryEntry.ActionType.valueOf(
                        cursor.getString(cursor.getColumnIndexOrThrow("action_type"))),
                nullableInteger(cursor, "quantity_before"),
                nullableInteger(cursor, "quantity_after"),
                nullableInteger(cursor, "threshold_before"),
                nullableInteger(cursor, "threshold_after"),
                cursor.getLong(cursor.getColumnIndexOrThrow("action_time")));
    }

    private Integer nullableInteger(Cursor cursor, String columnName) {
        int column = cursor.getColumnIndexOrThrow(columnName);
        return cursor.isNull(column) ? null : cursor.getInt(column);
    }
}
