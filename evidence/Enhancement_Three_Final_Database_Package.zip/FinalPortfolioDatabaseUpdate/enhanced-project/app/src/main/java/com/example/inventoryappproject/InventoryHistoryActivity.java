package com.example.inventoryappproject;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/** Read-only, owner-scoped audit trail for inventory changes. */
public final class InventoryHistoryActivity extends AppCompatActivity {
    static final int HISTORY_PAGE_SIZE = 25;
    private static final String STATE_LOADED_COUNT = "loaded_history_count";

    private InventoryRepository repository;
    private InventoryHistoryAdapter adapter;
    private TextView emptyView;
    private Button loadMoreButton;
    private int userId = -1;
    private Long nextActionTime;
    private Long nextHistoryId;
    private boolean initialized;
    private boolean loading;
    private int restoreItemCount = HISTORY_PAGE_SIZE;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_inventory_history);

        userId = getIntent().getIntExtra("user_id", -1);
        if (userId < 0) {
            finish();
            return;
        }
        if (state != null) {
            restoreItemCount = state.getInt(STATE_LOADED_COUNT, HISTORY_PAGE_SIZE);
        }

        String username = getIntent().getStringExtra("username");
        if (username == null || username.trim().isEmpty()) {
            username = getString(R.string.inventory_history);
        } else {
            username = getString(R.string.history_for_user, username);
        }
        ((TextView) findViewById(R.id.textHistoryTitle)).setText(username);

        repository = new SQLiteInventoryRepository(new DatabaseHelper(this));
        adapter = new InventoryHistoryAdapter();
        emptyView = findViewById(R.id.textHistoryEmpty);
        loadMoreButton = findViewById(R.id.buttonLoadMoreHistory);
        RecyclerView recycler = findViewById(R.id.recyclerHistory);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        recycler.setAdapter(adapter);
        loadMoreButton.setOnClickListener(view -> loadNextPage());
        findViewById(R.id.buttonHistoryBack).setOnClickListener(view -> finish());
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (repository == null || initialized) return;
        initialized = true;
        loadPage(false);
        while (adapter.getItemCount() < restoreItemCount
                && nextActionTime != null && nextHistoryId != null) {
            loadPage(true);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle state) {
        state.putInt(STATE_LOADED_COUNT, adapter == null ? 0 : adapter.getItemCount());
        super.onSaveInstanceState(state);
    }

    private void loadNextPage() {
        if (nextActionTime == null || nextHistoryId == null) return;
        loadPage(true);
    }

    private void loadPage(boolean append) {
        if (loading) return;
        loading = true;
        loadMoreButton.setEnabled(false);
        try {
            List<InventoryHistoryEntry> page = repository.findHistoryPageForOwner(
                    userId,
                    HISTORY_PAGE_SIZE,
                    append ? nextActionTime : null,
                    append ? nextHistoryId : null);
            if (append) {
                adapter.appendPage(page);
            } else {
                adapter.submitList(page);
            }

            if (!page.isEmpty()) {
                InventoryHistoryEntry last = page.get(page.size() - 1);
                nextActionTime = last.getActionTime();
                nextHistoryId = last.getHistoryId();
            }

            boolean anotherPageMayExist = page.size() == HISTORY_PAGE_SIZE;
            if (!anotherPageMayExist) {
                nextActionTime = null;
                nextHistoryId = null;
            }
            emptyView.setVisibility(adapter.getItemCount() == 0 ? View.VISIBLE : View.GONE);
            loadMoreButton.setVisibility(anotherPageMayExist ? View.VISIBLE : View.GONE);
            loadMoreButton.setEnabled(anotherPageMayExist);
        } finally {
            loading = false;
        }
    }
}
