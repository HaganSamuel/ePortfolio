package com.example.inventoryappproject;

public class InventoryItem {
    private final int id;
    private final String itemName;
    private final int quantity;
    private final int threshold;
    private final int ownerUserId;
    private final long createdAt;
    private final long updatedAt;

    public InventoryItem(int id, String itemName, int quantity, int threshold) {
        this(id, itemName, quantity, threshold, -1);
    }

    public InventoryItem(int id, String itemName, int quantity, int threshold, int ownerUserId) {
        this(id, itemName, quantity, threshold, ownerUserId, 0L, 0L);
    }

    public InventoryItem(int id, String itemName, int quantity, int threshold,
                         int ownerUserId, long createdAt, long updatedAt) {
        this.id = id;
        this.itemName = itemName;
        this.quantity = quantity;
        this.threshold = threshold;
        this.ownerUserId = ownerUserId;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public int getId() {
        return id;
    }

    public String getItemName() {
        return itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getThreshold() {
        return threshold;
    }

    public int getOwnerUserId() { return ownerUserId; }

    public long getCreatedAt() { return createdAt; }

    public long getUpdatedAt() { return updatedAt; }

    public int getUrgencyScore() { return threshold - quantity; }
}
