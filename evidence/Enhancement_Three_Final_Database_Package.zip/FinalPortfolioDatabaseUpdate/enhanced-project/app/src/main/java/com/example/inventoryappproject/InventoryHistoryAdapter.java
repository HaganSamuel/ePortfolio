package com.example.inventoryappproject;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** RecyclerView adapter for immutable inventory history snapshots. */
public final class InventoryHistoryAdapter
        extends RecyclerView.Adapter<InventoryHistoryAdapter.HistoryViewHolder> {
    private final List<InventoryHistoryEntry> entries = new ArrayList<>();
    private final SimpleDateFormat utcFormat;

    public InventoryHistoryAdapter() {
        utcFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US);
        utcFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
    }

    public void submitList(List<InventoryHistoryEntry> replacement) {
        entries.clear();
        entries.addAll(replacement);
        notifyDataSetChanged();
    }

    public void appendPage(List<InventoryHistoryEntry> page) {
        int start = entries.size();
        entries.addAll(page);
        notifyItemRangeInserted(start, page.size());
    }

    @NonNull
    @Override
    public HistoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory_history, parent, false);
        return new HistoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryViewHolder holder, int position) {
        InventoryHistoryEntry entry = entries.get(position);
        holder.action.setText(entry.getActionType().name() + " • "
                + entry.getItemNameSnapshot());
        holder.changes.setText("Quantity: " + transition(entry.getQuantityBefore(),
                entry.getQuantityAfter()) + "  |  Threshold: "
                + transition(entry.getThresholdBefore(), entry.getThresholdAfter()));
        holder.time.setText(utcFormat.format(new Date(entry.getActionTime())));
    }

    private String transition(Integer before, Integer after) {
        return display(before) + " → " + display(after);
    }

    private String display(Integer value) {
        return value == null ? "—" : String.valueOf(value);
    }

    @Override
    public int getItemCount() {
        return entries.size();
    }

    static final class HistoryViewHolder extends RecyclerView.ViewHolder {
        final TextView action;
        final TextView changes;
        final TextView time;

        HistoryViewHolder(View itemView) {
            super(itemView);
            action = itemView.findViewById(R.id.textHistoryAction);
            changes = itemView.findViewById(R.id.textHistoryChanges);
            time = itemView.findViewById(R.id.textHistoryTime);
        }
    }
}
