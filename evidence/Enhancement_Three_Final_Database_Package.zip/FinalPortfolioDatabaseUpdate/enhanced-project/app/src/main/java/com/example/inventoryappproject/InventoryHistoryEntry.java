package com.example.inventoryappproject;

/** Immutable snapshot of one owner-scoped inventory change. */
public final class InventoryHistoryEntry {
    public enum ActionType {
        ADD,
        UPDATE,
        DELETE
    }

    private final long historyId;
    private final Integer inventoryItemId;
    private final int ownerUserId;
    private final String itemNameSnapshot;
    private final ActionType actionType;
    private final Integer quantityBefore;
    private final Integer quantityAfter;
    private final Integer thresholdBefore;
    private final Integer thresholdAfter;
    private final long actionTime;

    public InventoryHistoryEntry(
            long historyId,
            Integer inventoryItemId,
            int ownerUserId,
            String itemNameSnapshot,
            ActionType actionType,
            Integer quantityBefore,
            Integer quantityAfter,
            Integer thresholdBefore,
            Integer thresholdAfter,
            long actionTime) {
        this.historyId = historyId;
        this.inventoryItemId = inventoryItemId;
        this.ownerUserId = ownerUserId;
        this.itemNameSnapshot = itemNameSnapshot;
        this.actionType = actionType;
        this.quantityBefore = quantityBefore;
        this.quantityAfter = quantityAfter;
        this.thresholdBefore = thresholdBefore;
        this.thresholdAfter = thresholdAfter;
        this.actionTime = actionTime;
    }

    public long getHistoryId() { return historyId; }

    public Integer getInventoryItemId() { return inventoryItemId; }

    public int getOwnerUserId() { return ownerUserId; }

    public String getItemNameSnapshot() { return itemNameSnapshot; }

    public ActionType getActionType() { return actionType; }

    public Integer getQuantityBefore() { return quantityBefore; }

    public Integer getQuantityAfter() { return quantityAfter; }

    public Integer getThresholdBefore() { return thresholdBefore; }

    public Integer getThresholdAfter() { return thresholdAfter; }

    public long getActionTime() { return actionTime; }
}
