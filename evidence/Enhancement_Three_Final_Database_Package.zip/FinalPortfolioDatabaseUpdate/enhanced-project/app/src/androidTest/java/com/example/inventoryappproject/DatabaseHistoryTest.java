package com.example.inventoryappproject;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

@RunWith(AndroidJUnit4.class)
public class DatabaseHistoryTest {
    private Context context;
    private DatabaseHelper helper;
    private int ownerId;

    @Before
    public void setUp() {
        context = InstrumentationRegistry.getInstrumentation().getTargetContext();
        context.deleteDatabase(DatabaseHelper.DATABASE_NAME);
        helper = new DatabaseHelper(context);
        assertTrue(helper.createUser("owner", "password123"));
        ownerId = helper.validateUser("owner", "password123");
        assertTrue(ownerId > 0);
    }

    @After
    public void tearDown() {
        if (helper != null) helper.close();
        context.deleteDatabase(DatabaseHelper.DATABASE_NAME);
    }

    @Test
    public void addWritesTimestampsAndAccurateHistorySnapshot() {
        int itemId = add("Paper", 3, 5);
        InventoryItem item = helper.getItems(ownerId).get(0);
        InventoryHistoryEntry event = helper.getHistoryForOwner(ownerId).get(0);

        assertEquals(itemId, item.getId());
        assertTrue(item.getCreatedAt() > 0);
        assertEquals(item.getCreatedAt(), item.getUpdatedAt());
        assertEquals(InventoryHistoryEntry.ActionType.ADD, event.getActionType());
        assertEquals(Integer.valueOf(itemId), event.getInventoryItemId());
        assertEquals("Paper", event.getItemNameSnapshot());
        assertNull(event.getQuantityBefore());
        assertEquals(Integer.valueOf(3), event.getQuantityAfter());
        assertNull(event.getThresholdBefore());
        assertEquals(Integer.valueOf(5), event.getThresholdAfter());
        assertEquals(item.getCreatedAt(), event.getActionTime());
    }

    @Test
    public void updatePreservesCreatedTimeAndRecordsBeforeAfterValues() {
        int itemId = add("Paper", 3, 5);
        InventoryItem before = helper.getItems(ownerId).get(0);

        assertEquals(itemId, helper.saveItem(
                new InventoryItem(itemId, "Paper Ream", 8, 4, ownerId)));
        InventoryItem after = helper.getItems(ownerId).get(0);
        InventoryHistoryEntry event = helper.getHistoryForOwner(ownerId).get(0);

        assertEquals(before.getCreatedAt(), after.getCreatedAt());
        assertTrue(after.getUpdatedAt() > before.getUpdatedAt());
        assertEquals("Paper Ream", after.getItemName());
        assertEquals(InventoryHistoryEntry.ActionType.UPDATE, event.getActionType());
        assertEquals("Paper Ream", event.getItemNameSnapshot());
        assertEquals(Integer.valueOf(3), event.getQuantityBefore());
        assertEquals(Integer.valueOf(8), event.getQuantityAfter());
        assertEquals(Integer.valueOf(5), event.getThresholdBefore());
        assertEquals(Integer.valueOf(4), event.getThresholdAfter());
        assertEquals(after.getUpdatedAt(), event.getActionTime());
    }

    @Test
    public void deleteRetainsSnapshotAndNullsDeletedItemForeignKey() {
        int itemId = add("Paper", 3, 5);

        assertEquals(1, helper.deleteItem(itemId, ownerId));
        assertTrue(helper.getItems(ownerId).isEmpty());
        InventoryHistoryEntry event = helper.getHistoryForOwner(ownerId).get(0);
        assertEquals(InventoryHistoryEntry.ActionType.DELETE, event.getActionType());
        assertNull(event.getInventoryItemId());
        assertEquals("Paper", event.getItemNameSnapshot());
        assertEquals(Integer.valueOf(3), event.getQuantityBefore());
        assertNull(event.getQuantityAfter());
        assertEquals(Integer.valueOf(5), event.getThresholdBefore());
        assertNull(event.getThresholdAfter());
    }

    @Test
    public void historyQueriesAreStrictlyOwnerScoped() {
        assertTrue(helper.createUser("other", "password456"));
        int otherId = helper.validateUser("other", "password456");
        add("Owner item", 1, 2);
        helper.saveItem(new InventoryItem(-1, "Other item", 4, 6, otherId));

        List<InventoryHistoryEntry> ownerHistory = helper.getHistoryForOwner(ownerId);
        List<InventoryHistoryEntry> otherHistory = helper.getHistoryForOwner(otherId);
        assertEquals(1, ownerHistory.size());
        assertEquals("Owner item", ownerHistory.get(0).getItemNameSnapshot());
        assertEquals(ownerId, ownerHistory.get(0).getOwnerUserId());
        assertEquals(1, otherHistory.size());
        assertEquals("Other item", otherHistory.get(0).getItemNameSnapshot());
        assertEquals(otherId, otherHistory.get(0).getOwnerUserId());
    }

    @Test
    public void wrongOwnerUpdateAndDeleteChangeNothingAndWriteNoHistory() {
        int itemId = add("Paper", 3, 5);
        assertTrue(helper.createUser("other", "password456"));
        int otherId = helper.validateUser("other", "password456");

        assertEquals(-1, helper.saveItem(
                new InventoryItem(itemId, "Stolen", 99, 99, otherId)));
        assertEquals(0, helper.deleteItem(itemId, otherId));

        InventoryItem unchanged = helper.getItems(ownerId).get(0);
        assertEquals("Paper", unchanged.getItemName());
        assertEquals(3, unchanged.getQuantity());
        assertEquals(1, helper.getHistoryForOwner(ownerId).size());
        assertTrue(helper.getHistoryForOwner(otherId).isEmpty());
    }

    @Test
    public void historyIsNewestFirstWithDeterministicIdTieBreak() {
        int itemId = add("Paper", 3, 5);
        helper.saveItem(new InventoryItem(itemId, "Paper", 4, 5, ownerId));
        helper.deleteItem(itemId, ownerId);

        List<InventoryHistoryEntry> events = helper.getHistoryForOwner(ownerId);
        assertEquals(3, events.size());
        assertEquals(InventoryHistoryEntry.ActionType.DELETE, events.get(0).getActionType());
        assertEquals(InventoryHistoryEntry.ActionType.UPDATE, events.get(1).getActionType());
        assertEquals(InventoryHistoryEntry.ActionType.ADD, events.get(2).getActionType());
        assertTrue(events.get(0).getActionTime() >= events.get(1).getActionTime());
        assertTrue(events.get(1).getActionTime() >= events.get(2).getActionTime());
        assertTrue(events.get(0).getHistoryId() > events.get(1).getHistoryId());
    }

    @Test
    public void foreignKeysAndCheckConstraintsAreEnforced() {
        SQLiteDatabase database = helper.getWritableDatabase();
        Cursor pragma = database.rawQuery("PRAGMA foreign_keys", null);
        assertTrue(pragma.moveToFirst());
        assertEquals(1, pragma.getInt(0));
        pragma.close();

        assertConstraint(() -> database.execSQL(
                "INSERT INTO inventory(item_name,quantity,threshold_value,owner_user_id,created_at,updated_at) "
                        + "VALUES('Bad',-1,0,?,1,1)", new Object[]{ownerId}));
        assertConstraint(() -> database.execSQL(
                "INSERT INTO inventory_history(inventory_item_id,owner_user_id,item_name_snapshot," 
                        + "action_type,action_time) VALUES(NULL,?,'Bad','RENAME',1)",
                new Object[]{ownerId}));
        assertConstraint(() -> database.execSQL(
                "INSERT INTO inventory_history(inventory_item_id,owner_user_id,item_name_snapshot," 
                        + "action_type,action_time) VALUES(NULL,999999,'Bad','ADD',1)"));
    }

    @Test
    public void addRollsBackWhenHistoryInsertFails() {
        rejectHistoryInserts();
        assertOperationFails(() -> add("Paper", 3, 5));
        assertTrue(helper.getItems(ownerId).isEmpty());
        assertTrue(helper.getHistoryForOwner(ownerId).isEmpty());
    }

    @Test
    public void updateRollsBackWhenHistoryInsertFails() {
        int itemId = add("Paper", 3, 5);
        InventoryItem before = helper.getItems(ownerId).get(0);
        rejectHistoryInserts();

        assertOperationFails(() -> helper.saveItem(
                new InventoryItem(itemId, "Changed", 8, 4, ownerId)));
        InventoryItem unchanged = helper.getItems(ownerId).get(0);
        assertEquals("Paper", unchanged.getItemName());
        assertEquals(3, unchanged.getQuantity());
        assertEquals(before.getUpdatedAt(), unchanged.getUpdatedAt());
        assertEquals(1, helper.getHistoryForOwner(ownerId).size());
    }

    @Test
    public void deleteRollsBackWhenHistoryInsertFails() {
        int itemId = add("Paper", 3, 5);
        rejectHistoryInserts();

        assertOperationFails(() -> helper.deleteItem(itemId, ownerId));
        assertFalse(helper.getItems(ownerId).isEmpty());
        assertEquals(1, helper.getHistoryForOwner(ownerId).size());
        assertEquals(InventoryHistoryEntry.ActionType.ADD,
                helper.getHistoryForOwner(ownerId).get(0).getActionType());
    }

    private int add(String name, int quantity, int threshold) {
        return (int) helper.saveItem(
                new InventoryItem(-1, name, quantity, threshold, ownerId));
    }

    private void rejectHistoryInserts() {
        helper.getWritableDatabase().execSQL(
                "CREATE TRIGGER reject_history BEFORE INSERT ON inventory_history "
                        + "BEGIN SELECT RAISE(ABORT, 'history rejected'); END");
    }

    private void assertConstraint(DatabaseAction action) {
        try {
            action.run();
            fail("Expected SQLite constraint failure");
        } catch (SQLiteConstraintException expected) {
            // Expected: the schema must reject invalid data.
        }
    }

    private void assertOperationFails(DatabaseAction action) {
        try {
            action.run();
            fail("Expected the history write to abort the transaction");
        } catch (RuntimeException expected) {
            // Expected: insertOrThrow propagates and the surrounding transaction rolls back.
        }
    }

    private interface DatabaseAction {
        void run();
    }
}
