package com.example.inventoryappproject;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.Visibility.GONE;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withEffectiveVisibility;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;

import androidx.recyclerview.widget.RecyclerView;
import androidx.test.core.app.ActivityScenario;
import androidx.test.espresso.ViewAssertion;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@RunWith(AndroidJUnit4.class)
public class InventoryHistoryPaginationTest {
    private static final long BASE_TIME = 2_000_000_000_000L;

    private Context context;
    private DatabaseHelper helper;
    private int ownerId;

    @Before
    public void setUp() {
        context = InstrumentationRegistry.getInstrumentation().getTargetContext();
        context.deleteDatabase(DatabaseHelper.DATABASE_NAME);
        helper = new DatabaseHelper(context);
        assertTrue(helper.createUser("page_owner", "password123"));
        ownerId = helper.validateUser("page_owner", "password123");
        assertTrue(ownerId > 0);
    }

    @After
    public void tearDown() {
        if (helper != null) helper.close();
        context.deleteDatabase(DatabaseHelper.DATABASE_NAME);
    }

    @Test
    public void firstPageReturnsNoMoreThanFixedPageSize() {
        seedHistory(ownerId, 63);

        List<InventoryHistoryEntry> first = firstPage(InventoryHistoryActivity.HISTORY_PAGE_SIZE);

        assertEquals(25, first.size());
    }

    @Test
    public void secondPageReturnsNextRecordsWithoutDuplicates() {
        seedHistory(ownerId, 63);
        List<InventoryHistoryEntry> first = firstPage(25);
        List<InventoryHistoryEntry> second = nextPage(first, 25);

        Set<Long> ids = historyIds(first);
        for (InventoryHistoryEntry entry : second) {
            assertTrue("Duplicate history ID across pages", ids.add(entry.getHistoryId()));
        }
        assertEquals(25, second.size());
        assertEquals(50, ids.size());
    }

    @Test
    public void combiningThreePagesReproducesExpectedNewestFirstSequence() {
        seedHistory(ownerId, 63);
        List<InventoryHistoryEntry> expected = helper.getHistoryForOwner(ownerId);
        List<InventoryHistoryEntry> paged = allPages(ownerId, 25);

        assertEquals(63, paged.size());
        assertEquals(historyIdsInOrder(expected), historyIdsInOrder(paged));
    }

    @Test
    public void equalActionTimesUseHistoryIdCursorWithoutSkipping() {
        seedHistory(ownerId, 3);

        List<InventoryHistoryEntry> first = firstPage(2);
        List<InventoryHistoryEntry> second = nextPage(first, 2);

        assertEquals(2, first.size());
        assertEquals(1, second.size());
        assertEquals(first.get(0).getActionTime(), first.get(1).getActionTime());
        assertEquals(first.get(1).getActionTime(), second.get(0).getActionTime());
        assertTrue(first.get(0).getHistoryId() > first.get(1).getHistoryId());
        assertTrue(first.get(1).getHistoryId() > second.get(0).getHistoryId());
    }

    @Test
    public void ownerIsolationHoldsAcrossEveryPage() {
        assertTrue(helper.createUser("other_owner", "password456"));
        int otherId = helper.validateUser("other_owner", "password456");
        seedHistory(ownerId, 63);
        seedHistory(otherId, 63);

        List<InventoryHistoryEntry> ownerPages = allPages(ownerId, 25);
        List<InventoryHistoryEntry> otherPages = allPages(otherId, 25);
        assertEquals(63, ownerPages.size());
        assertEquals(63, otherPages.size());
        for (InventoryHistoryEntry entry : ownerPages) {
            assertEquals(ownerId, entry.getOwnerUserId());
        }
        for (InventoryHistoryEntry entry : otherPages) {
            assertEquals(otherId, entry.getOwnerUserId());
        }
    }

    @Test
    public void emptyHistoryReturnsEmptyFirstPage() {
        assertTrue(firstPage(25).isEmpty());
    }

    @Test
    public void finalPartialPageContainsOnlyRemainingRows() {
        seedHistory(ownerId, 63);
        List<InventoryHistoryEntry> first = firstPage(25);
        List<InventoryHistoryEntry> second = nextPage(first, 25);
        List<InventoryHistoryEntry> third = nextPage(second, 25);

        assertEquals(25, first.size());
        assertEquals(25, second.size());
        assertEquals(13, third.size());
        assertTrue(nextPage(third, 25).isEmpty());
    }

    @Test
    public void invalidSizesAndIncompleteCursorsAreRejected() {
        assertIllegalArgument(() -> helper.getHistoryPageForOwner(ownerId, 0, null, null));
        assertIllegalArgument(() -> helper.getHistoryPageForOwner(
                ownerId, DatabaseHelper.MAX_HISTORY_PAGE_SIZE + 1, null, null));
        assertIllegalArgument(() -> helper.getHistoryPageForOwner(
                ownerId, 25, BASE_TIME, null));
        assertIllegalArgument(() -> helper.getHistoryPageForOwner(
                ownerId, 25, null, 1L));
    }

    @Test
    public void loadMoreUiAppendsAndRotationDoesNotDuplicateRows() {
        seedHistory(ownerId, 30);
        Intent intent = new Intent(context, InventoryHistoryActivity.class);
        intent.putExtra("user_id", ownerId);
        intent.putExtra("username", "page_owner");

        try (ActivityScenario<InventoryHistoryActivity> scenario =
                     ActivityScenario.launch(intent)) {
            onView(withId(R.id.recyclerHistory)).check(hasItemCount(25));
            onView(withId(R.id.buttonLoadMoreHistory)).check(matches(isDisplayed()));
            onView(withId(R.id.buttonLoadMoreHistory))
                    .perform(androidx.test.espresso.action.ViewActions.click());
            onView(withId(R.id.recyclerHistory)).check(hasItemCount(30));
            onView(withId(R.id.buttonLoadMoreHistory))
                    .check(matches(withEffectiveVisibility(GONE)));

            scenario.recreate();
            onView(withId(R.id.recyclerHistory)).check(hasItemCount(30));
            onView(withId(R.id.buttonLoadMoreHistory))
                    .check(matches(withEffectiveVisibility(GONE)));
        }
    }

    private List<InventoryHistoryEntry> firstPage(int pageSize) {
        return helper.getHistoryPageForOwner(ownerId, pageSize, null, null);
    }

    private List<InventoryHistoryEntry> nextPage(
            List<InventoryHistoryEntry> currentPage, int pageSize) {
        InventoryHistoryEntry last = currentPage.get(currentPage.size() - 1);
        return helper.getHistoryPageForOwner(
                ownerId, pageSize, last.getActionTime(), last.getHistoryId());
    }

    private List<InventoryHistoryEntry> allPages(int requestedOwnerId, int pageSize) {
        List<InventoryHistoryEntry> combined = new ArrayList<>();
        Long beforeActionTime = null;
        Long beforeHistoryId = null;
        while (true) {
            List<InventoryHistoryEntry> page = helper.getHistoryPageForOwner(
                    requestedOwnerId, pageSize, beforeActionTime, beforeHistoryId);
            combined.addAll(page);
            if (page.size() < pageSize) break;
            InventoryHistoryEntry last = page.get(page.size() - 1);
            beforeActionTime = last.getActionTime();
            beforeHistoryId = last.getHistoryId();
        }
        return combined;
    }

    private void seedHistory(int seedOwnerId, int count) {
        SQLiteDatabase database = helper.getWritableDatabase();
        database.beginTransaction();
        try {
            for (int i = 0; i < count; i++) {
                ContentValues values = new ContentValues();
                values.putNull("inventory_item_id");
                values.put("owner_user_id", seedOwnerId);
                values.put("item_name_snapshot", "History " + i);
                values.put("action_type", "ADD");
                values.putNull("quantity_before");
                values.put("quantity_after", i);
                values.putNull("threshold_before");
                values.put("threshold_after", i + 1);
                values.put("action_time", BASE_TIME - (i / 3));
                database.insertOrThrow("inventory_history", null, values);
            }
            database.setTransactionSuccessful();
        } finally {
            database.endTransaction();
        }
    }

    private Set<Long> historyIds(List<InventoryHistoryEntry> entries) {
        Set<Long> ids = new HashSet<>();
        for (InventoryHistoryEntry entry : entries) ids.add(entry.getHistoryId());
        return ids;
    }

    private List<Long> historyIdsInOrder(List<InventoryHistoryEntry> entries) {
        List<Long> ids = new ArrayList<>();
        for (InventoryHistoryEntry entry : entries) ids.add(entry.getHistoryId());
        return ids;
    }

    private ViewAssertion hasItemCount(int expected) {
        return (view, noViewFound) -> {
            if (noViewFound != null) throw noViewFound;
            RecyclerView recycler = (RecyclerView) view;
            assertTrue(recycler.getAdapter() != null);
            assertEquals(expected, recycler.getAdapter().getItemCount());
        };
    }

    private void assertIllegalArgument(DatabaseAction action) {
        try {
            action.run();
            fail("Expected invalid pagination request to be rejected");
        } catch (IllegalArgumentException expected) {
            // Expected.
        }
    }

    private interface DatabaseAction {
        void run();
    }
}
