package com.example.inventoryappproject;

import static org.junit.Assert.*;
import java.util.Arrays;
import java.util.List;
import org.junit.Test;

public class InventoryPolicyTest {
    @Test public void boundaryQuantityEqualToThresholdIsLowStock() {
        assertTrue(InventoryPolicy.isLowStock(new InventoryItem(1,"Boundary",5,5)));
        assertFalse(InventoryPolicy.isLowStock(new InventoryItem(2,"Above",6,5)));
        assertTrue(InventoryPolicy.isLowStock(new InventoryItem(3,"Zero",0,0)));
    }

    @Test public void urgencyUsesDeficitThenNameThenIdForTies() {
        List<InventoryItem> sorted = InventoryPolicy.filterAndSort(Arrays.asList(
                new InventoryItem(4,"Zulu",2,5),
                new InventoryItem(3,"alpha",2,5),
                new InventoryItem(2,"Alpha",2,5),
                new InventoryItem(1,"Critical",0,10),
                new InventoryItem(5,"Not low",6,5)), "", true);
        assertEquals(Arrays.asList(1,2,3,4), Arrays.asList(
                sorted.get(0).getId(), sorted.get(1).getId(), sorted.get(2).getId(), sorted.get(3).getId()));
    }

    @Test public void searchIsTrimmedAndCaseInsensitive() {
        List<InventoryItem> result = InventoryPolicy.filterAndSort(Arrays.asList(
                new InventoryItem(1,"Printer Paper",8,4), new InventoryItem(2,"Ink",1,2)), " PAPER ", false);
        assertEquals(1, result.size()); assertEquals("Printer Paper", result.get(0).getItemName());
    }
}
