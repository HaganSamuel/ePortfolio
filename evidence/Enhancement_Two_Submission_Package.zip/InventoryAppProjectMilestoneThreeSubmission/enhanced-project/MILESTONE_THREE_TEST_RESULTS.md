# Milestone Three Verification Results

Verification date: July 25, 2026 (America/Phoenix)

## Baseline and artifact integrity

- The committed Milestone Two project is preserved on branch `milestone-two` at commit
  `9cc2df65cdae88064eb9f9a3a8d10beafd777318`.
- The supplied `enhanced` project was imported on branch `milestone-three` and committed
  separately at `4b9032dce80e644f4aad65ed546f86a70aedf0f5` before the sorting enhancement.
- The frozen source archive was read but never modified:
  `InventoryAppProjectEnhancementOneWithArtifacts.zip`
- SHA-256 before implementation:
  `710C4D94F5ACED9B880DA04A2D531E1CAAA39811E88728F30E14F660A800E530`
- SHA-256 after implementation and testing:
  `710C4D94F5ACED9B880DA04A2D531E1CAAA39811E88728F30E14F660A800E530`

## Local unit tests

Command: `gradlew.bat testDebugUnitTest`

Result: **PASS — 15 tests, 0 failures, 0 errors**

- `InventoryPolicyTest`: 9 passed
- `InventoryValidatorTest`: 3 passed
- `PasswordHasherTest`: 2 passed
- `ExampleUnitTest`: 1 passed

The inventory policy coverage includes all four sort modes (name, quantity,
threshold, and urgency), duplicate primary values, case-insensitive name ties,
item-ID tie-breaking, empty lists, quantity-equals-threshold boundaries,
case-insensitive search, combined search/low-stock filtering, selected sorting
after filtering, and source-list immutability.

## Database migration instrumentation test

Target: `Medium_Phone_API_36.1` AVD, Android 16 / API 36

Test:
`DatabaseMigrationTest.versionOneUsersAndInventorySurviveVersionTwoMigration`

Result: **PASS — 1 test, 0 failures, 0 errors, 0 skipped**

The test verified that version-one users and inventory survive migration,
legacy passwords become salted hashes, plaintext password storage is removed,
and migrated inventory is assigned to the preserved owner.

## SMS permission workflows

Target: `Medium_Phone_API_36.1` AVD, Android 16 / API 36

Test setup: a disposable account, one low-stock item named `Paper` with quantity
`1` and threshold `5`, and emulator-only destination `5551234567`.

### Permission denied

Result: **PASS**

- The Android runtime permission prompt was displayed.
- Selecting **Don't allow** left `android.permission.SEND_SMS` at
  `granted=false` with the `USER_SET` flag.
- `InventoryActivity` remained the resumed activity, confirming inventory
  features stayed available after denial.

### Permission granted

Result: **PASS**

- Permission flags were reset to exercise a fresh prompt.
- Selecting **Allow** changed `android.permission.SEND_SMS` to `granted=true`.
- `InventoryActivity` remained resumed and no crash occurred.
- The emulator SMS provider recorded an outgoing message with:
  - address: `5551234567`
  - body: `Low inventory alert: Paper (1 left, threshold 5);`
  - type: `2` (sent)
  - creator: `com.example.inventoryappproject`
