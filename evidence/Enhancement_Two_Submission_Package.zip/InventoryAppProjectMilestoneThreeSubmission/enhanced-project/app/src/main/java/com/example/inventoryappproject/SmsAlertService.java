package com.example.inventoryappproject;

import android.telephony.SmsManager;
import java.util.List;

/** SMS transport and formatting; deliberately contains no validation or database access. */
public class SmsAlertService {
    public String buildMessage(List<InventoryItem> lowStockItems) {
        StringBuilder message = new StringBuilder("Low inventory alert: ");
        for (InventoryItem item : lowStockItems) {
            message.append(item.getItemName()).append(" (")
                    .append(item.getQuantity()).append(" left, threshold ")
                    .append(item.getThreshold()).append("); ");
        }
        return message.toString();
    }

    public void send(String phoneNumber, List<InventoryItem> lowStockItems) {
        SmsManager.getDefault().sendTextMessage(
                phoneNumber, null, buildMessage(lowStockItems), null, null);
    }
}
