package com.example.inventoryappproject;

import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public final class PasswordHasher {
    private static final int ITERATIONS = 120_000;
    private static final int KEY_BITS = 256;
    private PasswordHasher() { }

    public static String newSalt() {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }

    public static String hash(String password, String encodedSalt) {
        try {
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(),
                    Base64.getDecoder().decode(encodedSalt), ITERATIONS, KEY_BITS);
            byte[] hash = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(spec).getEncoded();
            spec.clearPassword();
            return Base64.getEncoder().encodeToString(hash);
        } catch (GeneralSecurityException error) {
            throw new IllegalStateException("Password hashing is unavailable", error);
        }
    }

    public static boolean matches(String password, String salt, String expected) {
        byte[] actualBytes = Base64.getDecoder().decode(hash(password, salt));
        byte[] expectedBytes = Base64.getDecoder().decode(expected);
        if (actualBytes.length != expectedBytes.length) return false;
        int difference = 0;
        for (int i = 0; i < actualBytes.length; i++) difference |= actualBytes[i] ^ expectedBytes[i];
        return difference == 0;
    }
}
