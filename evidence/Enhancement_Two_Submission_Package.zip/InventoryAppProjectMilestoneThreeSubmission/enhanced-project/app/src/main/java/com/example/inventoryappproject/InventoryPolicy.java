package com.example.inventoryappproject;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Pure inventory rules, independent of Android UI and persistence. */
public final class InventoryPolicy {
    private static final Comparator<InventoryItem> NAME_AND_ID_ORDER =
            Comparator.comparing(InventoryItem::getItemName, String.CASE_INSENSITIVE_ORDER)
                    .thenComparingInt(InventoryItem::getId);

    /**
     * EnumMap provides a fixed, type-safe lookup from each UI mode to its O(n log n)
     * comparator strategy. Every non-name key falls through to the same deterministic
     * case-insensitive-name and item-ID tie-breaker.
     */
    private static final Map<InventorySortMode, Comparator<InventoryItem>> SORT_ORDERS;

    static {
        EnumMap<InventorySortMode, Comparator<InventoryItem>> orders =
                new EnumMap<>(InventorySortMode.class);
        orders.put(InventorySortMode.NAME, NAME_AND_ID_ORDER);
        orders.put(InventorySortMode.QUANTITY,
                Comparator.comparingInt(InventoryItem::getQuantity)
                        .thenComparing(NAME_AND_ID_ORDER));
        orders.put(InventorySortMode.THRESHOLD,
                Comparator.comparingInt(InventoryItem::getThreshold)
                        .thenComparing(NAME_AND_ID_ORDER));
        orders.put(InventorySortMode.URGENCY,
                Comparator.comparingInt(InventoryItem::getUrgencyScore).reversed()
                        .thenComparing(NAME_AND_ID_ORDER));
        SORT_ORDERS = orders;
    }

    private InventoryPolicy() { }

    public static boolean isLowStock(InventoryItem item) {
        return item.getQuantity() <= item.getThreshold();
    }

    public static List<InventoryItem> filterAndSort(
            List<InventoryItem> source,
            String query,
            boolean lowStockOnly,
            InventorySortMode sortMode) {
        String normalized = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        List<InventoryItem> result = new ArrayList<>();
        for (InventoryItem item : source) {
            if ((!lowStockOnly || isLowStock(item))
                    && item.getItemName().toLowerCase(Locale.ROOT).contains(normalized)) {
                result.add(item);
            }
        }
        InventorySortMode selectedMode = sortMode == null ? InventorySortMode.NAME : sortMode;
        result.sort(SORT_ORDERS.get(selectedMode));
        return result;
    }

    /** Preserves the enhanced baseline's default behavior for existing callers. */
    public static List<InventoryItem> filterAndSort(
            List<InventoryItem> source, String query, boolean lowStockOnly) {
        return filterAndSort(source, query, lowStockOnly,
                lowStockOnly ? InventorySortMode.URGENCY : InventorySortMode.NAME);
    }
}
