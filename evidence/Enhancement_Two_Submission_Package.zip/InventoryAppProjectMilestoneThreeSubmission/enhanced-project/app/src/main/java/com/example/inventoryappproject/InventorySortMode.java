package com.example.inventoryappproject;

/** User-selectable ordering strategies for the inventory list. */
public enum InventorySortMode {
    NAME,
    QUANTITY,
    THRESHOLD,
    URGENCY
}
