package com.example.inventoryappproject;

public final class InventoryValidator {
    private InventoryValidator() { }

    public static InventoryItem parse(int id, int ownerId, String name, String quantity, String threshold) {
        String cleanName = name == null ? "" : name.trim();
        if (cleanName.isEmpty()) throw new IllegalArgumentException("Enter an item name.");
        final int parsedQuantity;
        final int parsedThreshold;
        try {
            parsedQuantity = Integer.parseInt(quantity == null ? "" : quantity.trim());
            parsedThreshold = Integer.parseInt(threshold == null ? "" : threshold.trim());
        } catch (NumberFormatException error) {
            throw new IllegalArgumentException("Quantity and threshold must be whole numbers.");
        }
        if (parsedQuantity < 0 || parsedThreshold < 0) {
            throw new IllegalArgumentException("Quantity and threshold cannot be negative.");
        }
        return new InventoryItem(id, cleanName, parsedQuantity, parsedThreshold, ownerId);
    }
}
