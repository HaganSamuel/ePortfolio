package com.example.inventoryappproject;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class InventoryActivity extends AppCompatActivity implements InventoryAdapter.Listener {
    private static final int SMS_PERMISSION_REQUEST_CODE = 1001;
    private InventoryRepository repository;
    private final SmsAlertService smsService = new SmsAlertService();
    private InventoryAdapter adapter;
    private EditText name, quantity, threshold, phone, search;
    private CheckBox lowStockOnly;
    private Button save;
    private InventorySortMode sortMode = InventorySortMode.NAME;
    private int editingItemId = -1;
    private int userId = -1;
    private String pendingPhone = "";
    private List<InventoryItem> pendingAlerts;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_inventory);
        userId = getIntent().getIntExtra("user_id", -1);
        if (userId < 0) { finish(); return; }
        repository = new SQLiteInventoryRepository(new DatabaseHelper(this));
        ((TextView)findViewById(R.id.textWelcome)).setText("Welcome, " + getIntent().getStringExtra("username"));
        name=findViewById(R.id.editItemName); quantity=findViewById(R.id.editItemQuantity);
        threshold=findViewById(R.id.editItemThreshold); phone=findViewById(R.id.editPhoneNumber);
        search=findViewById(R.id.editSearch); lowStockOnly=findViewById(R.id.checkLowStockOnly);
        save=findViewById(R.id.buttonSaveItem);
        adapter = new InventoryAdapter(this);
        RecyclerView recycler=findViewById(R.id.recyclerInventory);
        recycler.setLayoutManager(new LinearLayoutManager(this)); recycler.setNestedScrollingEnabled(false); recycler.setAdapter(adapter);
        save.setOnClickListener(v -> saveItem());
        findViewById(R.id.buttonClearForm).setOnClickListener(v -> clearForm());
        findViewById(R.id.buttonCheckAlerts).setOnClickListener(v -> prepareSms());
        lowStockOnly.setOnCheckedChangeListener((button, checked) -> refresh());
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){refresh();} public void afterTextChanged(Editable e){}
        });
        Spinner sortSelector = findViewById(R.id.spinnerSortMode);
        sortSelector.setSelection(sortMode.ordinal());
        sortSelector.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sortMode = InventorySortMode.values()[position];
                refresh();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {
                sortMode = InventorySortMode.NAME;
                refresh();
            }
        });
        refresh();
    }

    private void saveItem() {
        try {
            InventoryItem item = InventoryValidator.parse(editingItemId, userId,
                    name.getText().toString(), quantity.getText().toString(), threshold.getText().toString());
            if (repository.save(item) < 0) throw new IllegalStateException();
            Toast.makeText(this, editingItemId < 0 ? "Item added." : "Item updated.", Toast.LENGTH_SHORT).show();
            clearForm(); refresh();
        } catch (IllegalArgumentException error) {
            Toast.makeText(this, error.getMessage(), Toast.LENGTH_SHORT).show();
        } catch (RuntimeException error) {
            Toast.makeText(this, "Could not save item.", Toast.LENGTH_SHORT).show();
        }
    }

    private void refresh() {
        if (repository == null) return;
        adapter.submitList(InventoryPolicy.filterAndSort(repository.findForOwner(userId),
                search.getText().toString(), lowStockOnly.isChecked(), sortMode));
    }

    private void clearForm() { editingItemId=-1; name.setText(""); quantity.setText(""); threshold.setText(""); save.setText("Add Item"); }
    @Override public void onEdit(InventoryItem item) { editingItemId=item.getId(); name.setText(item.getItemName()); quantity.setText(String.valueOf(item.getQuantity())); threshold.setText(String.valueOf(item.getThreshold())); save.setText("Update Item"); }
    @Override public void onDelete(InventoryItem item) { repository.delete(item.getId(), userId); refresh(); }

    private void prepareSms() {
        pendingPhone = phone.getText().toString().trim();
        if (TextUtils.isEmpty(pendingPhone)) { Toast.makeText(this,"Enter a phone number first.",Toast.LENGTH_SHORT).show(); return; }
        pendingAlerts = InventoryPolicy.filterAndSort(repository.findForOwner(userId), "", true,
                InventorySortMode.URGENCY);
        if (pendingAlerts.isEmpty()) { Toast.makeText(this,"No low-stock items found.",Toast.LENGTH_SHORT).show(); return; }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) sendPendingSms();
        else ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.SEND_SMS},SMS_PERMISSION_REQUEST_CODE);
    }

    private void sendPendingSms() {
        try { smsService.send(pendingPhone, pendingAlerts); Toast.makeText(this,"SMS alert sent.",Toast.LENGTH_SHORT).show(); }
        catch (RuntimeException error) { Toast.makeText(this,"SMS failed to send.",Toast.LENGTH_SHORT).show(); }
    }

    @Override public void onRequestPermissionsResult(int requestCode,@NonNull String[] permissions,@NonNull int[] results) {
        super.onRequestPermissionsResult(requestCode,permissions,results);
        if (requestCode==SMS_PERMISSION_REQUEST_CODE && results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED) sendPendingSms();
        else if (requestCode==SMS_PERMISSION_REQUEST_CODE) Toast.makeText(this,"SMS permission denied. Inventory features remain available.",Toast.LENGTH_LONG).show();
    }
}
