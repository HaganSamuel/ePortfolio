package com.example.inventoryappproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

/** SQLite persistence gateway. Version 2 migrates rather than dropping user data. */
public class DatabaseHelper extends SQLiteOpenHelper {
    static final String DATABASE_NAME = "mobile2app.db";
    static final int DATABASE_VERSION = 2;

    public DatabaseHelper(Context context) { super(context, DATABASE_NAME, null, DATABASE_VERSION); }

    @Override public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, password_salt TEXT NOT NULL)");
        db.execSQL("CREATE TABLE inventory (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "item_name TEXT NOT NULL, quantity INTEGER NOT NULL CHECK(quantity >= 0), "
                + "threshold_value INTEGER NOT NULL CHECK(threshold_value >= 0), "
                + "owner_user_id INTEGER NOT NULL, FOREIGN KEY(owner_user_id) REFERENCES users(id) ON DELETE CASCADE)");
        db.execSQL("CREATE INDEX idx_inventory_owner_name ON inventory(owner_user_id, item_name)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) migrateVersionOneToTwo(db);
    }

    private void migrateVersionOneToTwo(SQLiteDatabase db) {
        db.beginTransaction();
        try {
            db.execSQL("ALTER TABLE users RENAME TO users_v1");
            db.execSQL("ALTER TABLE inventory RENAME TO inventory_v1");
            onCreate(db);

            Cursor users = db.query("users_v1", new String[]{"id", "username", "password"},
                    null, null, null, null, "id ASC");
            int firstUserId = -1;
            while (users.moveToNext()) {
                int id = users.getInt(0);
                if (firstUserId == -1) firstUserId = id;
                String salt = PasswordHasher.newSalt();
                ContentValues values = new ContentValues();
                values.put("id", id);
                values.put("username", users.getString(1));
                values.put("password_salt", salt);
                values.put("password_hash", PasswordHasher.hash(users.getString(2), salt));
                db.insertOrThrow("users", null, values);
            }
            users.close();

            if (firstUserId == -1) {
                String salt = PasswordHasher.newSalt();
                ContentValues legacyUser = new ContentValues();
                legacyUser.put("username", "legacy_inventory_owner");
                legacyUser.put("password_salt", salt);
                legacyUser.put("password_hash", PasswordHasher.hash(PasswordHasher.newSalt(), salt));
                firstUserId = (int) db.insertOrThrow("users", null, legacyUser);
            }

            db.execSQL("INSERT INTO inventory(id,item_name,quantity,threshold_value,owner_user_id) "
                    + "SELECT id,item_name,quantity,threshold_value,? FROM inventory_v1",
                    new Object[]{firstUserId});
            db.execSQL("DROP TABLE inventory_v1");
            db.execSQL("DROP TABLE users_v1");
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public boolean createUser(String username, String password) {
        String salt = PasswordHasher.newSalt();
        ContentValues values = new ContentValues();
        values.put("username", username.trim());
        values.put("password_salt", salt);
        values.put("password_hash", PasswordHasher.hash(password, salt));
        return getWritableDatabase().insert("users", null, values) != -1;
    }

    public int validateUser(String username, String password) {
        Cursor cursor = getReadableDatabase().query("users",
                new String[]{"id", "password_hash", "password_salt"}, "username=?",
                new String[]{username.trim()}, null, null, null);
        int userId = -1;
        if (cursor.moveToFirst() && PasswordHasher.matches(password, cursor.getString(2), cursor.getString(1))) {
            userId = cursor.getInt(0);
        }
        cursor.close();
        return userId;
    }

    public long saveItem(InventoryItem item) {
        ContentValues values = itemValues(item);
        if (item.getId() < 0) return getWritableDatabase().insert("inventory", null, values);
        int updated = getWritableDatabase().update("inventory", values,
                "id=? AND owner_user_id=?", new String[]{String.valueOf(item.getId()), String.valueOf(item.getOwnerUserId())});
        return updated > 0 ? item.getId() : -1;
    }

    private ContentValues itemValues(InventoryItem item) {
        ContentValues values = new ContentValues();
        values.put("item_name", item.getItemName());
        values.put("quantity", item.getQuantity());
        values.put("threshold_value", item.getThreshold());
        values.put("owner_user_id", item.getOwnerUserId());
        return values;
    }

    public int deleteItem(int id, int ownerId) {
        return getWritableDatabase().delete("inventory", "id=? AND owner_user_id=?",
                new String[]{String.valueOf(id), String.valueOf(ownerId)});
    }

    public List<InventoryItem> getItems(int ownerId) {
        List<InventoryItem> items = new ArrayList<>();
        Cursor cursor = getReadableDatabase().query("inventory", null, "owner_user_id=?",
                new String[]{String.valueOf(ownerId)}, null, null, "item_name COLLATE NOCASE ASC, id ASC");
        while (cursor.moveToNext()) {
            items.add(new InventoryItem(cursor.getInt(cursor.getColumnIndexOrThrow("id")),
                    cursor.getString(cursor.getColumnIndexOrThrow("item_name")),
                    cursor.getInt(cursor.getColumnIndexOrThrow("quantity")),
                    cursor.getInt(cursor.getColumnIndexOrThrow("threshold_value")), ownerId));
        }
        cursor.close();
        return items;
    }
}
