package com.example.inventoryappproject;

import static org.junit.Assert.*;
import org.junit.Test;

public class InventoryValidatorTest {
    @Test public void acceptsBoundaryValues() {
        InventoryItem item=InventoryValidator.parse(-1,7," Bolts ","0","0");
        assertEquals("Bolts",item.getItemName()); assertEquals(0,item.getQuantity()); assertEquals(7,item.getOwnerUserId());
    }
    @Test(expected=IllegalArgumentException.class) public void rejectsNegativeQuantity() { InventoryValidator.parse(-1,1,"Bolts","-1","0"); }
    @Test(expected=IllegalArgumentException.class) public void rejectsNonNumericThreshold() { InventoryValidator.parse(-1,1,"Bolts","1","many"); }
}
