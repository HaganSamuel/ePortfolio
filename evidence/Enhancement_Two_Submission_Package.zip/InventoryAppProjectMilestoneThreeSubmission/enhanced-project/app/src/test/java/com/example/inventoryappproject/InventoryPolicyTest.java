package com.example.inventoryappproject;

import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Test;

public class InventoryPolicyTest {
    @Test public void lowStockIncludesBoundaryAndExcludesJustAboveThreshold() {
        assertTrue(InventoryPolicy.isLowStock(new InventoryItem(1,"Boundary",5,5)));
        assertFalse(InventoryPolicy.isLowStock(new InventoryItem(2,"Above",6,5)));
        assertTrue(InventoryPolicy.isLowStock(new InventoryItem(3,"Zero",0,0)));

        List<InventoryItem> filtered = InventoryPolicy.filterAndSort(Arrays.asList(
                new InventoryItem(1,"Below",4,5),
                new InventoryItem(2,"Boundary",5,5),
                new InventoryItem(3,"Above",6,5)),
                "", true, InventorySortMode.NAME);

        assertEquals(Arrays.asList(1,2), ids(filtered));
    }

    @Test public void nameSortIsCaseInsensitiveAndUsesIdForDuplicateNames() {
        List<InventoryItem> sorted = InventoryPolicy.filterAndSort(Arrays.asList(
                new InventoryItem(4,"beta",1,1),
                new InventoryItem(3,"Alpha",1,1),
                new InventoryItem(2,"alpha",1,1),
                new InventoryItem(1,"Gamma",1,1)),
                "", false, InventorySortMode.NAME);

        assertEquals(Arrays.asList(2,3,4,1), ids(sorted));
    }

    @Test public void quantitySortIsAscendingAndBreaksDuplicateValuesByNameThenId() {
        List<InventoryItem> sorted = InventoryPolicy.filterAndSort(Arrays.asList(
                new InventoryItem(4,"Zulu",2,9),
                new InventoryItem(3,"alpha",2,8),
                new InventoryItem(2,"Alpha",2,7),
                new InventoryItem(1,"Single",1,6)),
                "", false, InventorySortMode.QUANTITY);

        assertEquals(Arrays.asList(1,2,3,4), ids(sorted));
    }

    @Test public void thresholdSortIsAscendingAndBreaksDuplicateValuesByNameThenId() {
        List<InventoryItem> sorted = InventoryPolicy.filterAndSort(Arrays.asList(
                new InventoryItem(4,"Zulu",9,2),
                new InventoryItem(3,"alpha",8,2),
                new InventoryItem(2,"Alpha",7,2),
                new InventoryItem(1,"Single",6,1)),
                "", false, InventorySortMode.THRESHOLD);

        assertEquals(Arrays.asList(1,2,3,4), ids(sorted));
    }

    @Test public void urgencySortIsDescendingAndBreaksDuplicateValuesByNameThenId() {
        List<InventoryItem> sorted = InventoryPolicy.filterAndSort(Arrays.asList(
                new InventoryItem(4,"Zulu",2,5),
                new InventoryItem(3,"alpha",2,5),
                new InventoryItem(2,"Alpha",2,5),
                new InventoryItem(1,"Critical",0,10),
                new InventoryItem(5,"Not low",6,5)),
                "", false, InventorySortMode.URGENCY);

        assertEquals(Arrays.asList(1,2,3,4,5), ids(sorted));
    }

    @Test public void searchIsTrimmedAndCaseInsensitive() {
        List<InventoryItem> result = InventoryPolicy.filterAndSort(Arrays.asList(
                new InventoryItem(1,"Printer Paper",8,4),
                new InventoryItem(2,"Ink",1,2)),
                " PAPER ", false, InventorySortMode.NAME);

        assertEquals(1, result.size()); assertEquals("Printer Paper", result.get(0).getItemName());
    }

    @Test public void emptyListReturnsEmptyForEverySortMode() {
        for (InventorySortMode mode : InventorySortMode.values()) {
            assertTrue(InventoryPolicy.filterAndSort(
                    Collections.emptyList(), "", false, mode).isEmpty());
        }
    }

    @Test public void searchLowStockFilterAndSelectedSortComposeInOnePipeline() {
        List<InventoryItem> result = InventoryPolicy.filterAndSort(Arrays.asList(
                new InventoryItem(1,"Printer Paper",8,4),
                new InventoryItem(2,"paper Clips",1,2),
                new InventoryItem(3,"PAPER Labels",2,2),
                new InventoryItem(4,"Ink",0,4)),
                " paper ", true, InventorySortMode.QUANTITY);

        assertEquals(Arrays.asList(2,3), ids(result));
    }

    @Test public void filteringAndSortingDoNotMutateTheSourceList() {
        List<InventoryItem> source = new ArrayList<>(Arrays.asList(
                new InventoryItem(2,"Zulu",2,2),
                new InventoryItem(1,"Alpha",1,1)));

        InventoryPolicy.filterAndSort(source, "", false, InventorySortMode.NAME);

        assertEquals(Arrays.asList(2,1), ids(source));
    }

    private static List<Integer> ids(List<InventoryItem> items) {
        List<Integer> ids = new ArrayList<>();
        for (InventoryItem item : items) {
            ids.add(item.getId());
        }
        return ids;
    }
}
