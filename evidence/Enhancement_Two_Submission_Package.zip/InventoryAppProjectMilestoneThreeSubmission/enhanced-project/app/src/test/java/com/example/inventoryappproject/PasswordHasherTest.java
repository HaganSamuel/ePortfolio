package com.example.inventoryappproject;

import static org.junit.Assert.*;
import org.junit.Test;

public class PasswordHasherTest {
    @Test public void saltedHashMatchesOnlyCorrectPassword() {
        String salt=PasswordHasher.newSalt(); String hash=PasswordHasher.hash("correct horse",salt);
        assertNotEquals("correct horse",hash); assertTrue(PasswordHasher.matches("correct horse",salt,hash)); assertFalse(PasswordHasher.matches("wrong",salt,hash));
    }
    @Test public void identicalPasswordsUseDifferentSalts() {
        String a=PasswordHasher.newSalt(), b=PasswordHasher.newSalt(); assertNotEquals(PasswordHasher.hash("same",a),PasswordHasher.hash("same",b));
    }
}
