# Inventory App Milestone Three Submission

This package contains two clean project exports and a verification bundle.

- `original-project/` was exported from commit
  `4b9032dce80e644f4aad65ed546f86a70aedf0f5`.
- `enhanced-project/` was exported from commit
  `36d4fd7526e34aa76f64d6f4f6057ecbccb83d9d`.
- `verification/` contains preserved unit and migration test reports, the
  Milestone Three verification summary, and raw SMS permission/send evidence.

The project exports exclude `.git`, `.gradle`, `.idea`, `build`, and
`local.properties`.

Repository: https://github.com/HaganSamuel/InventoryAppProject

Published branches:

- `milestone-two`
- `milestone-three`
