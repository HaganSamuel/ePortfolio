# Verification Contents

## Preserved automated test evidence

- `unit-test-results/`: raw Gradle/JUnit unit-test results, including suite XML.
- `unit-test-report/`: generated HTML unit-test report and its assets.
- `migration-test-results/`: raw connected-device instrumentation results,
  device diagnostics, test log, and migration-test logcat.
- `migration-test-report/`: generated HTML instrumentation report and assets.
- `MILESTONE_THREE_TEST_RESULTS.md`: human-readable verification summary.

## Raw SMS workflow evidence

The `sms-workflow-evidence/` folder contains:

- emulator/AVD and API identity;
- denial and grant permission-dialog UI hierarchies;
- denial and grant permission-dialog screenshots;
- post-action UI hierarchies;
- package permission state and resumed-activity output;
- SEND_SMS app-op output;
- raw logcat captures for both workflows; and
- raw sent-SMS provider output showing the address, expected low-stock body,
  sent type, and creator package.

The phone number is an emulator-only `555` test number. No real recipient was
used.

## Commit provenance

- Original project export:
  `4b9032dce80e644f4aad65ed546f86a70aedf0f5`
- Enhanced project export:
  `36d4fd7526e34aa76f64d6f4f6057ecbccb83d9d`

The frozen source archive remained external to this package and was not
modified. Its verified SHA-256 was:

`710C4D94F5ACED9B880DA04A2D531E1CAAA39811E88728F30E14F660A800E530`
