
�
�
DatabaseMigrationTestcom.example.inventoryappproject5versionOneUsersAndInventorySurviveVersionTwoMigration2�������D:�������1B
emulator-5554primary"�

logcatandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\logcat-com.example.inventoryappproject.DatabaseMigrationTest-versionOneUsersAndInventorySurviveVersionTwoMigration.txt"�

device-infoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\device-info.pb"�

device-info.meminfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\meminfo"�

device-info.cpuinfoandroid�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�C:\Users\hagan\AndroidStudioProjects\InventoryAppProject\app\build\outputs\androidTest-results\connected\debug\Medium_Phone_API_36.1(AVD) - 16\testlog\test-results.log 2
text/plain