package com.example.inventoryappproject;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Typeface;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 1001;

    private DatabaseHelper databaseHelper;

    private TextView textWelcome;
    private EditText editItemName;
    private EditText editItemQuantity;
    private EditText editItemThreshold;
    private EditText editPhoneNumber;
    private Button buttonSaveItem;
    private Button buttonClearForm;
    private Button buttonCheckAlerts;
    private TableLayout tableInventory;

    private int editingItemId = -1;
    private String pendingPhoneNumber = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new DatabaseHelper(this);

        textWelcome = findViewById(R.id.textWelcome);
        editItemName = findViewById(R.id.editItemName);
        editItemQuantity = findViewById(R.id.editItemQuantity);
        editItemThreshold = findViewById(R.id.editItemThreshold);
        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        buttonSaveItem = findViewById(R.id.buttonSaveItem);
        buttonClearForm = findViewById(R.id.buttonClearForm);
        buttonCheckAlerts = findViewById(R.id.buttonCheckAlerts);
        tableInventory = findViewById(R.id.tableInventory);

        String username = getIntent().getStringExtra("username");
        if (username != null) {
            textWelcome.setText("Welcome, " + username);
        }

        buttonSaveItem.setOnClickListener(v -> saveOrUpdateItem());
        buttonClearForm.setOnClickListener(v -> clearForm());
        buttonCheckAlerts.setOnClickListener(v -> checkAlertsAndSendSms());

        renderInventoryTable();
    }

    private void saveOrUpdateItem() {
        String itemName = editItemName.getText().toString().trim();
        String quantityText = editItemQuantity.getText().toString().trim();
        String thresholdText = editItemThreshold.getText().toString().trim();

        if (TextUtils.isEmpty(itemName) || TextUtils.isEmpty(quantityText) || TextUtils.isEmpty(thresholdText)) {
            Toast.makeText(this, "Enter item name, quantity, and threshold.", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity;
        int threshold;

        try {
            quantity = Integer.parseInt(quantityText);
            threshold = Integer.parseInt(thresholdText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Quantity and threshold must be numbers.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (editingItemId == -1) {
            long result = databaseHelper.addItem(itemName, quantity, threshold);
            if (result != -1) {
                Toast.makeText(this, "Item added.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Could not add item.", Toast.LENGTH_SHORT).show();
            }
        } else {
            int result = databaseHelper.updateItem(editingItemId, itemName, quantity, threshold);
            if (result > 0) {
                Toast.makeText(this, "Item updated.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Could not update item.", Toast.LENGTH_SHORT).show();
            }
        }

        clearForm();
        renderInventoryTable();
    }

    private void clearForm() {
        editingItemId = -1;
        editItemName.setText("");
        editItemQuantity.setText("");
        editItemThreshold.setText("");
        buttonSaveItem.setText("Add Item");
    }

    private void loadItemIntoForm(InventoryItem item) {
        editingItemId = item.getId();
        editItemName.setText(item.getItemName());
        editItemQuantity.setText(String.valueOf(item.getQuantity()));
        editItemThreshold.setText(String.valueOf(item.getThreshold()));
        buttonSaveItem.setText("Update Item");
    }

    private void renderInventoryTable() {
        tableInventory.removeAllViews();

        TableRow headerRow = new TableRow(this);
        headerRow.addView(makeHeaderCell("Item"));
        headerRow.addView(makeHeaderCell("Qty"));
        headerRow.addView(makeHeaderCell("Limit"));
        headerRow.addView(makeHeaderCell("Edit"));
        headerRow.addView(makeHeaderCell("Delete"));
        tableInventory.addView(headerRow);

        List<InventoryItem> items = databaseHelper.getAllItems();

        for (InventoryItem item : items) {
            TableRow row = new TableRow(this);

            row.addView(makeBodyCell(item.getItemName()));
            row.addView(makeBodyCell(String.valueOf(item.getQuantity())));
            row.addView(makeBodyCell(String.valueOf(item.getThreshold())));

            Button editButton = new Button(this);
            editButton.setText("Edit");
            editButton.setOnClickListener(v -> loadItemIntoForm(item));
            row.addView(editButton);

            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");
            deleteButton.setOnClickListener(v -> {
                databaseHelper.deleteItem(item.getId());
                Toast.makeText(this, "Item deleted.", Toast.LENGTH_SHORT).show();
                renderInventoryTable();
            });
            row.addView(deleteButton);

            tableInventory.addView(row);
        }
    }

    private TextView makeHeaderCell(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setTypeface(null, Typeface.BOLD);
        textView.setPadding(16, 16, 16, 16);
        return textView;
    }

    private TextView makeBodyCell(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(16, 16, 16, 16);
        return textView;
    }

    private void checkAlertsAndSendSms() {
        String phoneNumber = editPhoneNumber.getText().toString().trim();

        if (TextUtils.isEmpty(phoneNumber)) {
            Toast.makeText(this, "Enter a phone number first.", Toast.LENGTH_SHORT).show();
            return;
        }

        List<InventoryItem> lowStockItems = databaseHelper.getLowStockItems();

        if (lowStockItems.isEmpty()) {
            Toast.makeText(this, "No low-stock items found.", Toast.LENGTH_SHORT).show();
            return;
        }

        pendingPhoneNumber = phoneNumber;

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            sendLowStockSms(pendingPhoneNumber);
        } else {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE
            );
        }
    }

    private void sendLowStockSms(String phoneNumber) {
        List<InventoryItem> lowStockItems = databaseHelper.getLowStockItems();

        if (lowStockItems.isEmpty()) {
            Toast.makeText(this, "No low-stock items to report.", Toast.LENGTH_SHORT).show();
            return;
        }

        StringBuilder messageBuilder = new StringBuilder("Low inventory alert: ");

        for (InventoryItem item : lowStockItems) {
            messageBuilder
                    .append(item.getItemName())
                    .append(" (")
                    .append(item.getQuantity())
                    .append(" left, limit ")
                    .append(item.getThreshold())
                    .append("); ");
        }

        String message = messageBuilder.toString();

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS alert sent.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS failed to send.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendLowStockSms(pendingPhoneNumber);
            } else {
                Toast.makeText(
                        this,
                        "SMS permission denied. The rest of the app still works.",
                        Toast.LENGTH_LONG
                ).show();
            }
        }
    }
}