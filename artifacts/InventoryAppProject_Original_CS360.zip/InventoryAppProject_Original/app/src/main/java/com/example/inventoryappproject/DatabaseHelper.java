package com.example.inventoryappproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "mobile2app.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_USERS = "users";
    private static final String TABLE_INVENTORY = "inventory";

    private static final String COL_USER_ID = "id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    private static final String COL_ITEM_ID = "id";
    private static final String COL_ITEM_NAME = "item_name";
    private static final String COL_QUANTITY = "quantity";
    private static final String COL_THRESHOLD = "threshold_value";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " ("
                + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USERNAME + " TEXT UNIQUE NOT NULL, "
                + COL_PASSWORD + " TEXT NOT NULL)";

        String createInventoryTable = "CREATE TABLE " + TABLE_INVENTORY + " ("
                + COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_ITEM_NAME + " TEXT NOT NULL, "
                + COL_QUANTITY + " INTEGER NOT NULL, "
                + COL_THRESHOLD + " INTEGER NOT NULL)";

        db.execSQL(createUsersTable);
        db.execSQL(createInventoryTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    public boolean createUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);

        long result;
        try {
            result = db.insert(TABLE_USERS, null, values);
        } catch (Exception e) {
            result = -1;
        }

        return result != -1;
    }

    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{COL_USER_ID},
                COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password},
                null,
                null,
                null
        );

        boolean isValid = cursor.moveToFirst();
        cursor.close();
        return isValid;
    }

    public long addItem(String itemName, int quantity, int threshold) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, itemName);
        values.put(COL_QUANTITY, quantity);
        values.put(COL_THRESHOLD, threshold);
        return db.insert(TABLE_INVENTORY, null, values);
    }

    public int updateItem(int id, String itemName, int quantity, int threshold) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, itemName);
        values.put(COL_QUANTITY, quantity);
        values.put(COL_THRESHOLD, threshold);

        return db.update(
                TABLE_INVENTORY,
                values,
                COL_ITEM_ID + "=?",
                new String[]{String.valueOf(id)}
        );
    }

    public int deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(
                TABLE_INVENTORY,
                COL_ITEM_ID + "=?",
                new String[]{String.valueOf(id)}
        );
    }

    public List<InventoryItem> getAllItems() {
        List<InventoryItem> items = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_INVENTORY,
                null,
                null,
                null,
                null,
                null,
                COL_ITEM_NAME + " ASC"
        );

        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ITEM_ID));
            String itemName = cursor.getString(cursor.getColumnIndexOrThrow(COL_ITEM_NAME));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COL_QUANTITY));
            int threshold = cursor.getInt(cursor.getColumnIndexOrThrow(COL_THRESHOLD));

            items.add(new InventoryItem(id, itemName, quantity, threshold));
        }

        cursor.close();
        return items;
    }

    public List<InventoryItem> getLowStockItems() {
        List<InventoryItem> items = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT * FROM " + TABLE_INVENTORY
                + " WHERE " + COL_QUANTITY + " <= " + COL_THRESHOLD
                + " ORDER BY " + COL_ITEM_NAME + " ASC";

        Cursor cursor = db.rawQuery(query, null);

        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ITEM_ID));
            String itemName = cursor.getString(cursor.getColumnIndexOrThrow(COL_ITEM_NAME));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COL_QUANTITY));
            int threshold = cursor.getInt(cursor.getColumnIndexOrThrow(COL_THRESHOLD));

            items.add(new InventoryItem(id, itemName, quantity, threshold));
        }

        cursor.close();
        return items;
    }
}