package com.example.inventoryappproject;

public class InventoryItem {
    private final int id;
    private final String itemName;
    private final int quantity;
    private final int threshold;

    public InventoryItem(int id, String itemName, int quantity, int threshold) {
        this.id = id;
        this.itemName = itemName;
        this.quantity = quantity;
        this.threshold = threshold;
    }

    public int getId() {
        return id;
    }

    public String getItemName() {
        return itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getThreshold() {
        return threshold;
    }
}