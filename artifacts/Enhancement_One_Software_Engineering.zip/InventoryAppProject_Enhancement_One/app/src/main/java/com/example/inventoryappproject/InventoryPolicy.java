package com.example.inventoryappproject;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Pure inventory rules, independent of Android UI and persistence. */
public final class InventoryPolicy {
    private InventoryPolicy() { }

    public static boolean isLowStock(InventoryItem item) {
        return item.getQuantity() <= item.getThreshold();
    }

    public static final Comparator<InventoryItem> URGENCY_ORDER =
            Comparator.comparingInt(InventoryItem::getUrgencyScore).reversed()
                    .thenComparing(InventoryItem::getItemName, String.CASE_INSENSITIVE_ORDER)
                    .thenComparingInt(InventoryItem::getId);

    public static List<InventoryItem> filterAndSort(
            List<InventoryItem> source, String query, boolean lowStockOnly) {
        String normalized = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        List<InventoryItem> result = new ArrayList<>();
        for (InventoryItem item : source) {
            if ((!lowStockOnly || isLowStock(item))
                    && item.getItemName().toLowerCase(Locale.ROOT).contains(normalized)) {
                result.add(item);
            }
        }
        result.sort(lowStockOnly ? URGENCY_ORDER
                : Comparator.comparing(InventoryItem::getItemName, String.CASE_INSENSITIVE_ORDER)
                .thenComparingInt(InventoryItem::getId));
        return result;
    }
}
