package com.example.inventoryappproject;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public final class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ItemViewHolder> {
    public interface Listener { void onEdit(InventoryItem item); void onDelete(InventoryItem item); }
    private final Listener listener;
    private final List<InventoryItem> items = new ArrayList<>();
    public InventoryAdapter(Listener listener) { this.listener = listener; }
    public void submitList(List<InventoryItem> replacement) {
        items.clear(); items.addAll(replacement); notifyDataSetChanged();
    }
    @NonNull @Override public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ItemViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_inventory, parent, false));
    }
    @Override public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        InventoryItem item = items.get(position);
        holder.name.setText(item.getItemName());
        holder.details.setText("Quantity " + item.getQuantity() + " | Threshold " + item.getThreshold()
                + (InventoryPolicy.isLowStock(item) ? " | LOW (urgency " + item.getUrgencyScore() + ")" : ""));
        holder.edit.setOnClickListener(v -> listener.onEdit(item));
        holder.delete.setOnClickListener(v -> listener.onDelete(item));
    }
    @Override public int getItemCount() { return items.size(); }
    static final class ItemViewHolder extends RecyclerView.ViewHolder {
        final TextView name, details; final Button edit, delete;
        ItemViewHolder(View view) { super(view); name=view.findViewById(R.id.itemName); details=view.findViewById(R.id.itemDetails); edit=view.findViewById(R.id.buttonEdit); delete=view.findViewById(R.id.buttonDelete); }
    }
}
