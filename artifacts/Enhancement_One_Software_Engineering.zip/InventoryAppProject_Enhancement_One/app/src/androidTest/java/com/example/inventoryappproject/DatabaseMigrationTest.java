package com.example.inventoryappproject;

import static org.junit.Assert.*;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class DatabaseMigrationTest {
    private Context context;
    @Before public void setUp() { context=InstrumentationRegistry.getInstrumentation().getTargetContext(); context.deleteDatabase(DatabaseHelper.DATABASE_NAME); }
    @After public void tearDown() { context.deleteDatabase(DatabaseHelper.DATABASE_NAME); }

    @Test public void versionOneUsersAndInventorySurviveVersionTwoMigration() {
        SQLiteDatabase v1=context.openOrCreateDatabase(DatabaseHelper.DATABASE_NAME,Context.MODE_PRIVATE,null);
        v1.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL)");
        v1.execSQL("CREATE TABLE inventory (id INTEGER PRIMARY KEY AUTOINCREMENT, item_name TEXT NOT NULL, quantity INTEGER NOT NULL, threshold_value INTEGER NOT NULL)");
        v1.execSQL("INSERT INTO users(id,username,password) VALUES(7,'sam','secret')");
        v1.execSQL("INSERT INTO inventory(id,item_name,quantity,threshold_value) VALUES(11,'Paper',3,5)");
        v1.setVersion(1); v1.close();

        DatabaseHelper migrated=new DatabaseHelper(context); migrated.getWritableDatabase();
        assertEquals(7,migrated.validateUser("sam","secret"));
        assertEquals(1,migrated.getItems(7).size());
        InventoryItem item=migrated.getItems(7).get(0);
        assertEquals(11,item.getId()); assertEquals("Paper",item.getItemName()); assertEquals(7,item.getOwnerUserId());
        Cursor columns=migrated.getReadableDatabase().rawQuery("PRAGMA table_info(users)",null);
        boolean hasHash=false, hasPlaintext=false;
        while(columns.moveToNext()){ String column=columns.getString(1); hasHash|="password_hash".equals(column); hasPlaintext|="password".equals(column); }
        columns.close(); assertTrue(hasHash); assertFalse(hasPlaintext); migrated.close();
    }
}
